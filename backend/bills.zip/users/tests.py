from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        ("bills", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="Payment",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("dra_username", models.CharField(max_length=150)),
                ("payment_method", models.CharField(choices=[("cash", "Cash"), ("upi", "UPI"), ("cheque", "Cheque"), ("electronic", "Electronic")], max_length=20)),
                ("amount", models.DecimalField(decimal_places=2, max_digits=12)),
                ("transaction_number", models.CharField(blank=True, max_length=255)),
                ("cheque_number", models.CharField(blank=True, max_length=255)),
                ("cheque_date", models.DateField(blank=True, null=True)),
                ("cheque_type", models.CharField(blank=True, choices=[("rtgs", "RTGS"), ("neft", "NEFT"), ("imps", "IMPS")], max_length=20)),
                ("cheque_status", models.CharField(choices=[("pending", "Pending"), ("cleared", "Cleared"), ("bounced", "Bounced")], default="pending", max_length=20)),
                ("firm", models.CharField(choices=[("NA", "NA"), ("MZ", "MZ")], default="NA", max_length=10)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("bill", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="payments", to="bills.bill")),
            ],
            options={"ordering": ["-created_at"]},
        ),
    ]